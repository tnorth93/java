package yourworkhere;

public abstract class Account {
	protected String accountId;
	protected double balance;
	protected String accountType;
	protected String firstName;
	protected String lastName;
	
	//GETTERS
	public String getAccountId() {
		return this.accountId;
	}
	
	public double getBalance() {
		return this.balance;
	}
	
	public String getAccountType() {
		return this.accountType;
	}
	
	public String getFirstName() {
		return this.firstName;
	}
	
	public String getLastName() {
		return this.lastName;
	}
	
	//SETTERS
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	// GET ACCOUNT MANAGER
	public abstract IAccountManager getAccountManager();
	
}
