package yourworkhere;

public class SavingsAccount extends Account {
	double minBalance;
	int currentMonthlyWithdrawals;
	int maxMonthlyWithdrawals;
	String accountType = "savings";
	
	//constructors =========================================
	public SavingsAccount(){}
	
	public SavingsAccount(String accountId, String firstName, String lastName) {
		this.accountId = accountId;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	
	// =====================================================
	
	//minBalance ===========================================
	public double getMinBalance() {
		return this.minBalance;
	}
	
	public void setMinBalance(double minBalance) {
		this.minBalance = minBalance;
	}
	// =====================================================
	
	//currentMonthlyWithdrawals ============================
	public int getCurrentMonthlyWithdrawals() {
		return this.currentMonthlyWithdrawals;
	}
	
	public void setCurrentMonthlyWithdrawals(int cmw) {
		this.currentMonthlyWithdrawals = cmw;
	}
	// =====================================================
	
	//maxMonthlyWithdrawals ================================
	public int getMaxMonthlyWithdrawals() {
		return this.maxMonthlyWithdrawals;
	}
	
	public void setMaxMonthlyWithdrawals(int mmw) {
		this.maxMonthlyWithdrawals = mmw;
	}
	// =====================================================
	
	//overriding toString method ===========================
	@Override
	public String toString() {
		return accountId + " " 
		+ firstName + " " 
		+ lastName + " " 
		+ accountType + " " 
		+ balance + " " 
		+ minBalance + " " 
		+ currentMonthlyWithdrawals + " " 
		+ maxMonthlyWithdrawals ;
	}
	
	public static void main(String[] args) {
		SavingsAccount test = new SavingsAccount("457384", "Tom", "North");
		System.out.println(test.toString());
	}

	// GET ACCOUNT MANAGER ===================================
	@Override
	public IAccountManager getAccountManager() {
		return new SavingsAccountManager(this);
	}

}
