package yourworkhere;

public class CheckingAccountManager implements IAccountManager {
	public CheckingAccount checkingAccount;

	public CheckingAccountManager(CheckingAccount checkingAccount) {
		this.checkingAccount = checkingAccount;
	}
	
	public Boolean withdraw(double amount) {
		double oldBalance = this.checkingAccount.getBalance();
		double newBalance = oldBalance - amount;
		double overDraftFee = this.checkingAccount.getOverDraftFee();
		if (newBalance < 0) {
			newBalance -= overDraftFee;
		}
		this.checkingAccount.setBalance(newBalance);
		return true;
	}
	
	public Boolean deposit(double amount) {
		double oldBalance = this.checkingAccount.getBalance();
		double newBalance = oldBalance + amount;
		this.checkingAccount.setBalance(newBalance);
		return true;
	}
}
