package yourworkhere;

import java.util.ArrayList;
import java.util.HashMap;

public class Ledger {
	// FIELDS
	private static final Ledger instance = new Ledger();
	private HashMap<String, Account> accounts = new HashMap<>();
	
	// CONSTRUCTOR
	private Ledger() {};

	// METHODS
	public static Ledger getInstance() {
		return instance;
	}
	
	// Adding or updating an account
	public Boolean store(String id, Account account) {
		if (accounts.containsKey(id)) {
			accounts.put(id, account);
			return false;
		} else {
			accounts.put(id, account);
			return true;
		}
	}
	
	// Retrieving an account
	public Account retrieve(String id) {
		if (accounts.containsKey(id)) {
			return accounts.get(id);
		}
		return null;
}
	
	// Create an Account
	
	public Account createAccount(String accountType, String firstName, String lastName) {
		if (accountType.toLowerCase() == "savings") {
			SavingsAccount newAccount = new SavingsAccount(getNextAccountId(), firstName, lastName);
			return newAccount;
		} else if (accountType.toLowerCase() == "checking") {
			CheckingAccount newAccount = new CheckingAccount(getNextAccountId(), firstName, lastName);
			return newAccount;
		}
		return null;
	}
	
	// Get the next ID for an account
	public String getNextAccountId() {
		int nextId = accounts.size() + 1;
		String id = Integer.toString(nextId);
		return id;
	}
	
	// Lists all of the accounts in the ledger
	public ArrayList<Account> getAllAccounts() {
		ArrayList<Account> list = new ArrayList<>();
		accounts.forEach((id, account) -> list.add(account));
		return list;
	}	
}
