package yourworkhere;

public class SavingsAccountManager implements IAccountManager {
	public SavingsAccount savingsAccount;
	
	public SavingsAccountManager(SavingsAccount savingsAccount) {
		this.savingsAccount = savingsAccount;
	}
	
	public Boolean withdraw(double amount) {
		int currentMonthlyWithdrawals = this.savingsAccount.getCurrentMonthlyWithdrawals();
		int maxMonthlyWithdrawals = this.savingsAccount.getMaxMonthlyWithdrawals();
		double balance = this.savingsAccount.getBalance();
		double minBalance = this.savingsAccount.getMinBalance();
		if (currentMonthlyWithdrawals >= maxMonthlyWithdrawals) {
			return false;
		} else if ((balance - amount) < minBalance) {
			return false;
		} else {
			double newBalance = balance - amount;
			this.savingsAccount.setBalance(newBalance);
			this.savingsAccount.setCurrentMonthlyWithdrawals(currentMonthlyWithdrawals + 1);
			return true;
		}	
	}
	
	public Boolean deposit(double amount) {
		double oldBalance = this.savingsAccount.getBalance();
		double newBalance = oldBalance + amount;
		this.savingsAccount.setBalance(newBalance);
		return true;
	}
}
