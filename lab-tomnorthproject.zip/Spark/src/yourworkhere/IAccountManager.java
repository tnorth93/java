package yourworkhere;

public interface IAccountManager {
	public Boolean deposit(double amount);
	
	public Boolean withdraw(double amount);
}
