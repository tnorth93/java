package yourworkhere;

import java.util.ArrayList;

public class Reporter {
	
	// FIELDS
	Ledger ledger = Ledger.getInstance();
	
	// METHODS
	
	// Get number of accounts
	public int getNumAccounts() {
		return ledger.getAllAccounts().size();
	}
	
	// Get a list of accounts that have at minimum the specified balance
	public ArrayList<Account> getAccountsWithMinimum(double amount) {
		ArrayList<Account> qualifyingAccounts = new ArrayList<Account>();
		ArrayList<Account> allAccounts = ledger.getAllAccounts();
		allAccounts.forEach((account) -> {
			if (account.getBalance() >= amount) {
				qualifyingAccounts.add(account);
			}
		});
		return qualifyingAccounts;
	}
	
	// Print details of all of the accounts in the ledger
	public void printAllAccounts() {
		ArrayList<Account> allAccounts = ledger.getAllAccounts();
		allAccounts.forEach((account) -> {
			System.out.println(account.toString());
		});
	}
	
	// Get a number of all the accounts with the specified type
	public int getNumAccountsByType(String account) {
		ArrayList<Account> qualifyingAccounts = new ArrayList<Account>();
		ArrayList<Account> allAccounts = ledger.getAllAccounts();
		allAccounts.forEach((anAccount) -> {
			if (anAccount.accountType == account.toLowerCase()) {
				qualifyingAccounts.add(anAccount);
			}
		});
		return qualifyingAccounts.size();
	}
}
