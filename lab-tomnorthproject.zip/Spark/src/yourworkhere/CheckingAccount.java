package yourworkhere;

public class CheckingAccount extends Account {
	double overDraftFee;
	String accountType = "checking";
	CheckingAccountManager checkingAccountManager;
	
	//constructors ===============================
	public CheckingAccount(){}
	
	public CheckingAccount(String accountId, String firstName, String lastName)  {
		this.accountId = accountId;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	// ===========================================
	
	
	//get and set ================================
	public double getOverDraftFee() {
		return this.overDraftFee;
	}
	
	public void setOverDraftFee(double odf) {
		this.overDraftFee = odf;
	}
	// ===========================================
	
	//overriding toString method ================
	@Override
	public String toString() {
		return accountId + " " 
		+ firstName + " " 
		+ lastName + " " 
		+ accountType + " " 
		+ balance + " " 
		+ overDraftFee;
	}
	
	public static void main(String[] args) {
		CheckingAccount test = new CheckingAccount("457384", "Tom", "North");
		System.out.println(test.toString());
	}
	
	// GET ACCOUNT MANAGER
	@Override
	public IAccountManager getAccountManager() {
		return new CheckingAccountManager(this);
	}
}
