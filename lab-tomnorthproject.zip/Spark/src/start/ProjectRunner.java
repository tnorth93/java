package start;

import ignore.gui.MainFrame;

public class ProjectRunner {

	public static void main(String[] args) {
		MainFrame.main(null);
	}
}
